import 'package:flutter/material.dart';

class AppTheme {
  static final ThemeData lightTheme = ThemeData(
    primaryColor: const Color.fromARGB(255, 0, 0, 255),
    colorScheme: const ColorScheme.light(
      primary: Color.fromARGB(255, 0, 0, 255),
      secondary: Color.fromARGB(255, 255, 0, 0),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color.fromARGB(255, 0, 0, 255),
      foregroundColor: Colors.white,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: Color.fromARGB(255, 0, 0, 255),
      foregroundColor: Colors.white,
    ),
    textTheme: const TextTheme(
      // ignore: deprecated_member_use
      headline6: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.black,
      ),
      // ignore: deprecated_member_use
      bodyText2: TextStyle(
        fontSize: 16,
        color: Colors.black87,
      ),
    ),
  );

  static final ThemeData darkTheme = ThemeData(
    primaryColor: const Color.fromARGB(255, 0, 0, 155),
    colorScheme: const ColorScheme.dark(
      primary: Color.fromARGB(255, 0, 0, 155),
      secondary: Color.fromARGB(255, 255, 0, 0),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color.fromARGB(255, 0, 0, 155),
      foregroundColor: Colors.white,
    ),
  );
}