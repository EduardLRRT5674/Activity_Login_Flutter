import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final Scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Configuración'),
        centerTitle: true,
        backgroundColor: Scheme.primary,
        foregroundColor: Scheme.onPrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ajustes de la Aplicación',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            Text(
              'Cuenta',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Scheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 20),
            settingsCard(
              context,
              title: 'Cambiar Email',
              subtitle: 'Establecer un nuevo correo electrónico',
              icon: Icons.email,
            ),
            settingsCard(
              context,
              title: 'Cambiar Contraseña',
              subtitle: 'Actualizar tu contraseña',
              icon: Icons.lock,
            ),
            Text(
              'Apariencia',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Scheme.onSurface.withOpacity(0.6),
              ),
            ),
            settingsCard(
              context,
              title: 'Tema',
              subtitle: 'Personalizar colores y aspecto',
              icon: Icons.color_lens,
            ),
            settingsCard(
              context,
              title: 'Idioma',
              subtitle: 'Seleccionar idioma de la aplicación',
              icon: Icons.language,
            ),
          ],
        ),
      ),
    );
  }

  Widget settingsCard(
    BuildContext context, {
      required String title,
      required String subtitle,
      required IconData icon,
      VoidCallback? onTap,
    }) {
      final scheme = Theme.of(context).colorScheme;
      return Card(
        margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: scheme.primaryContainer,
            child: Icon(icon, color: scheme.primary),
          ),
          title: Text(
            title, style: const TextStyle(fontWeight: FontWeight.bold
          )
        ),
        subtitle: Text(subtitle),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: 16.0,
          color: scheme.onSurface.withOpacity(0.6),
        ),
      ),
    );
  }
}